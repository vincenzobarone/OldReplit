// Service Worker for Markeplay Notifier PWA
// Versione: 2025.04.09.171236 - CORREZIONE 14.2: MIGLIORAMENTO GESTIONE PERCORSI SUBDIR

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !! CORREZIONE 14.1 - MODALITÀ PERSISTENZA PER NOTIFICHE POST-LOGOUT   !!
// !! FLAG STAYCONNECTED DETERMINA SE RICEVERE NOTIFICHE DOPO LOGOUT     !!
// !! SEMPRE UTILIZZO URL DIRETTO MARKEPLAY                              !!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !! CORREZIONE 14.2 - MIGLIORAMENTO COMPATIBILITÀ PERCORSI SUBDIR     !!
// !! GESTIONE OTTIMIZZATA ASSETS E NAVIGAZIONE IN /applications/       !!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

const VERSION = '2025.04.09.165056';
const CACHE_NAME = `markeplay-notifier-v${VERSION}`;
const BASE_PATH = '/applications/notificationapp';

// Array dinamico degli asset da mettere in cache
// Funzione che genera percorsi multipli per massima compatibilità
function generateAssetPaths() {
  // Asset principali dell'applicazione
  const mainAssets = [
    '/',
    '/index.html',
    '/manifest.json',
    '/favicon.ico',
    '/icon.svg',
    '/icon-192x192.png',
    '/icon-512x512.png'
  ];
  
  // Array per contenere tutti i percorsi generati
  const allPaths = [];
  
  // Genera versioni degli asset con tutti i possibili prefissi di percorso
  mainAssets.forEach(asset => {
    // Versione con BASE_PATH completo (es. /applications/notificationapp/index.html)
    allPaths.push(`${BASE_PATH}${asset}`);
    
    // Versione relativa senza slash iniziale per supportare BASE_PATH dinamici
    if (asset.startsWith('/')) {
      allPaths.push(asset.substring(1));
    }
  });
  
  console.log('Asset paths generati per la cache:', allPaths);
  return allPaths;
}

// Genera le versioni dei percorsi di tutti gli asset
const ASSETS_TO_CACHE = generateAssetPaths();

// Install event - cache assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        return cache.addAll(ASSETS_TO_CACHE);
      })
      .then(() => {
        return self.skipWaiting();
      })
  );
});

// Gestione messaggio per forzare l'aggiornamento del service worker e altri eventi
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    console.log('[ServiceWorker] Ricevuto messaggio SKIP_WAITING, forzo l\'aggiornamento immediato');
    self.skipWaiting();
  }
  
  // CORREZIONE 14.1: Gestisci messaggio di logout dall'app
  if (event.data && event.data.type === 'USER_LOGGED_OUT') {
    console.log('[ServiceWorker] Ricevuto messaggio USER_LOGGED_OUT, gestione logout utente');
    
    // Ottieni il flag stayConnected dall'evento se disponibile (CORREZIONE 14.1)
    const stayConnected = event.data.stayConnected === true;
    
    // Gestiamo il flag di controllo continuo delle notifiche
    try {
      // Imposta il flag di stato logout per persistere tra riavvii
      // Il flag 'user_logged_out' indica che l'utente ha fatto logout (indipendentemente da stayConnected)
      localStorage.setItem('user_logged_out', 'true');
      
      // Gestiamo il flag stayConnected separatamente
      if (stayConnected) {
        console.log('[ServiceWorker] Flag stayConnected=true, il service worker continuerà a verificare i messaggi anche dopo logout');
        localStorage.setItem('stay_connected', 'true');
      } else {
        console.log('[ServiceWorker] Flag stayConnected=false');
        localStorage.setItem('stay_connected', 'false');
      }
    } catch (e) {
      console.error('[ServiceWorker] Errore nel salvare i flag di stato utente:', e);
    }
    
    // Pulizia completa dei dati utente in IndexedDB, ma solo se stayConnected è false
    try {
      if (indexedDB && !stayConnected) {
        // Pulizia completa di IndexedDB solo se non dobbiamo mantenere la connessione
        const clearUserData = () => {
          const request = indexedDB.open('markeplay-notifier', 1);
          
          request.onsuccess = (event) => {
            try {
              const db = event.target.result;
              if (db.objectStoreNames.contains('user')) {
                const transaction = db.transaction('user', 'readwrite');
                const store = transaction.objectStore('user');
                const clearRequest = store.clear();
                
                clearRequest.onsuccess = () => {
                  console.log('[ServiceWorker] Dati utente eliminati con successo da IndexedDB');
                };
                
                clearRequest.onerror = (error) => {
                  console.error('[ServiceWorker] Errore nella pulizia dati utente:', error);
                };
              }
            } catch (error) {
              console.error('[ServiceWorker] Errore durante la pulizia IndexedDB:', error);
            }
          };
          
          request.onerror = (event) => {
            console.error('[ServiceWorker] Errore apertura IndexedDB per pulizia:', event);
          };
        };
        
        // Esegui la pulizia solo se stayConnected è false
        clearUserData();
      } else if (stayConnected) {
        console.log('[ServiceWorker] Mantenimento dei dati utente in IndexedDB per stayConnected=true');
      }
    } catch (error) {
      console.error('[ServiceWorker] Errore generale durante la pulizia dopo logout:', error);
    }
  }
});

// Activate event - clean up old caches and register periodic sync
self.addEventListener('activate', (event) => {
  console.log('[ServiceWorker] Activate event - versione 2025.04.09.171236 - CORREZIONE 14.1: DISATTIVA NOTIFICHE DOPO LOGOUT SE NON RICHIESTO');
  
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((cacheName) => {
            return cacheName !== CACHE_NAME;
          })
          .map((cacheName) => {
            console.log('[ServiceWorker] Eliminazione cache obsoleta:', cacheName);
            return caches.delete(cacheName);
          })
      );
    }).then(() => {
      // Start periodic check for notifications (every minute)
      console.log('[ServiceWorker] Impostazione controllo notifiche periodico (ogni minuto)');
      setInterval(checkForNewNotifications, 60000);
      return self.clients.claim();
    })
  );
});

// Fetch event - network first, cache fallback strategy con gestione percorsi migliorata
self.addEventListener('fetch', (event) => {
  // Skip cross-origin requests
  if (!event.request.url.startsWith(self.location.origin)) {
    return;
  }
  
  // API requests should not be cached
  if (event.request.url.includes('/api/')) {
    return;
  }
  
  // CORREZIONE 14.2: Gestione migliorata per i percorsi in subdir
  // Se la richiesta è per la navigazione HTML (accept header include text/html)
  // e non contiene .js, .css, etc. potrebbe essere una richiesta di navigazione
  const isNavigationRequest = event.request.mode === 'navigate' || 
                           (event.request.method === 'GET' && 
                            event.request.headers.get('accept')?.includes('text/html'));
                           
  // URL senza parametri di query
  const cleanUrl = new URL(event.request.url);
  const pathname = cleanUrl.pathname;
  
  // Determina se è possibilmente una richiesta di navigazione ad una route SPA
  const isSpaRouteRequest = isNavigationRequest && 
                           !pathname.includes('.') && 
                           pathname !== '/' && 
                           !pathname.endsWith('/index.html');
  
  // Log per debug
  if (isSpaRouteRequest) {
    console.log('[ServiceWorker] Possibile richiesta navigazione SPA:', pathname);
  }
  
  event.respondWith(
    // Prima tentiamo di ottenere la risorsa dalla rete
    fetch(event.request)
      .then((response) => {
        // Cache la risposta se valida
        if (response.status === 200) {
          const responseToCache = response.clone();
          caches.open(CACHE_NAME)
            .then((cache) => {
              cache.put(event.request, responseToCache);
            });
        }
        return response;
      })
      .catch(() => {
        // Se il fetch fallisce, proviamo a servire dalla cache
        return caches.match(event.request).then((cachedResponse) => {
          // Se abbiamo una risposta in cache, la restituiamo
          if (cachedResponse) {
            return cachedResponse;
          }
          
          // CORREZIONE 14.2: Gestione speciale per le route SPA
          // Se è una richiesta di navigazione senza estensione (probabile route SPA)
          // Serviamo index.html (gestione con client-side routing)
          if (isSpaRouteRequest) {
            console.log('[ServiceWorker] Richiesta route SPA fallita, serving index.html per:', pathname);
            // Prova tutte le possibili versioni di index.html nella cache
            return caches.match('/index.html')
              .then(response => response || caches.match(`${BASE_PATH}/index.html`))
              .then(response => response || caches.match('index.html'));
          }
          
          // Se non è stata servita ancora, proviamo a localizzarla nel BASE_PATH
          if (pathname.startsWith('/') && !pathname.startsWith(BASE_PATH)) {
            const alternativePath = `${BASE_PATH}${pathname}`;
            console.log('[ServiceWorker] Tentativo alternativo con BASE_PATH:', alternativePath);
            return caches.match(alternativePath);
          }
          
          // Fallback finale
          return new Response('Service Unavailable', {
            status: 503,
            statusText: 'Service Unavailable',
            headers: new Headers({
              'Content-Type': 'text/plain'
            })
          });
        });
      })
  );
});

// Push notification event
self.addEventListener('push', (event) => {
  if (!event.data) return;
  
  try {
    const data = event.data.json();
    const options = {
      body: data.message || 'New notification from Markeplay',
      icon: `${BASE_PATH}/icon-192x192.png`,
      badge: `${BASE_PATH}/icon-192x192.png`,
      image: data.imageUrl || undefined,
      vibrate: [200, 100, 200],
      data: {
        url: data.link || BASE_PATH + '/'
      }
    };
    
    event.waitUntil(
      self.registration.showNotification(data.title || 'Markeplay Notifier', options)
    );
  } catch (error) {
    // Fallback for non-JSON data
    const message = event.data.text();
    event.waitUntil(
      self.registration.showNotification('Markeplay Notifier', {
        body: message,
        icon: `${BASE_PATH}/icon-192x192.png`,
        badge: `${BASE_PATH}/icon-192x192.png`,
        vibrate: [200, 100, 200]
      })
    );
  }
});

// Notification click event
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  
  event.waitUntil(
    clients.matchAll({ type: 'window' })
      .then((clientList) => {
        // If we have a matching client, focus it
        for (const client of clientList) {
          if ((client.url === BASE_PATH + '/' || client.url === BASE_PATH) && 'focus' in client) {
            return client.focus();
          }
        }
        
        // Otherwise open a new window
        if (clients.openWindow) {
          const url = event.notification.data?.url || `${BASE_PATH}/`;
          return clients.openWindow(url);
        }
      })
  );
});

// Periodic background sync for checking notifications
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'check-notifications') {
    event.waitUntil(checkForNewNotifications());
  }
});

// Function to check for new notifications in the background
async function checkForNewNotifications() {
  try {
    // CORREZIONE 14.1: Verifica se dobbiamo continuare a controllare le notifiche dopo il logout
    // Le notifiche devono essere disattivate SOLO se utente ha fatto logout E non ha selezionato stayConnected
    try {
      // Controlliamo entrambi i flag separatamente per maggiore chiarezza
      const isUserLoggedOut = localStorage.getItem('user_logged_out') === 'true';
      const isStayConnected = localStorage.getItem('stay_connected') === 'true';
      
      // Se l'utente ha fatto logout E non ha selezionato stayConnected, interrompiamo i controlli
      if (isUserLoggedOut && !isStayConnected) {
        console.log('[ServiceWorker] Controllo notifiche disabilitato (utente ha fatto logout e non ha selezionato stayConnected)');
        return;
      }
      
      // IMPORTANTE: In tutti gli altri casi, continuiamo a controllare le notifiche:
      // 1. L'utente è loggato (isUserLoggedOut === false)
      // 2. L'utente ha fatto logout MA ha selezionato stayConnected
      if (isUserLoggedOut && isStayConnected) {
        console.log('[ServiceWorker] Controllo notifiche attivo nonostante il logout (stayConnected selezionato)');
      } else if (!isUserLoggedOut) {
        console.log('[ServiceWorker] Controllo notifiche attivo (utente loggato o prima esecuzione)');
      }
    } catch (e) {
      console.log('[ServiceWorker] Errore nell\'accesso a localStorage:', e);
      // Continuiamo comunque per compatibilità
    }
    
    const user = await getUser();
    if (!user) return;
    
    // Prima verifichiamo se ci sono nuove notifiche tramite l'API Markeplay
    // Includiamo esplicitamente la challenge key nelle chiamate fetch dal service worker
    // Questo valore deve corrispondere esattamente a quello definito in constants.ts
    const NOTIFICATION_CHALLENGE_KEY = 'FASDGWXCNK994?--';
    // Logga i dettagli della richiesta per debug
    console.log('[ServiceWorker] Esecuzione check-messages con challenge key nel body della richiesta');
    console.log('[ServiceWorker] Body challenge key:', NOTIFICATION_CHALLENGE_KEY);
    console.log('[ServiceWorker] User ID:', user.id);
    console.log('[ServiceWorker] UniqueID:', user.uniqueId);
    
    // CORREZIONE 13.0: ABSOLUTE URL FISSO SENZA LOGICA CONDIZIONALE
    // BYPASS COMPLETO DEL RILEVAMENTO AMBIENTE - NESSUNA POSSIBILITÀ DI OVERRIDE
    
    // FORZIAMO IL DIRETTO MARKEPLAY API SENZA CONDIZIONI E SENZA POSSIBILITÀ DI MODIFICHE
    console.log('[ServiceWorker] CORREZIONE 13.0: URL COSTANTE STATICO SENZA POSSIBILITÀ DI MODIFICA');
    
    // Solo per logging
    const isReplit = self.location.hostname.includes('.replit.dev');
    const isLocalhost = self.location.hostname === 'localhost' || self.location.hostname === '127.0.0.1';
    const isMarkeplayApiHost = self.location.hostname === 'serviceapi.markeplay.com';
    const isMarkeplaySite = self.location.hostname.includes('markeplay.com');
    
    // ATTENZIONE: SEMPRE VERO TRANNE IN DEVELOPMENT ESPLICITO
    let isProduction = true; // Usiamo let per poterlo modificare
    
    // Per test locale: development solo su localhost e replit
    const isDevelopment = isReplit || isLocalhost;
    
    // Disabilitiamo la produzione solo su localhost e replit
    if (isDevelopment) {
      console.log('[ServiceWorker] Ambiente di sviluppo (localhost/replit) rilevato: utilizzo endpoint proxy');
      isProduction = false;
    } else {
      console.log('[ServiceWorker] ⚠️ FORCING PRODUZIONE: utilizzo URL diretto Markeplay API');
    }
    
    console.log('[ServiceWorker] Environment detected (CORREZIONE 13.0 - URL COSTANTE FISSO):', {
      isMarkeplayApiHost,
      isMarkeplaySite, 
      isProduction,
      isReplit,
      isLocalhost,
      isDevelopment,
      hostname: self.location.hostname,
      forceDirectUrl: true // SEMPRE ABILITATO da questa versione
    });
                          
    // !!! CORREZIONE 13.0: URL ASSOLUTO COMPLETAMENTE FISSO SENZA ALCUNA LOGICA CONDIZIONALE !!!
    // !!! ATTENZIONE: NESSUN SE, NESSUN MA, NESSUNA CONDIZIONE - SOLO URL FISSO !!!
    
    // HARDCODED URL - CONSTANT FISSO CHE NON PUÒ MAI ESSERE MODIFICATO DA NESSUNA CONDIZIONE
    // IL VALORE È COSTANTE, NON UNA VARIABILE - NON PUÒ ESSERE RIASSEGNATO IN ALCUN CASO
    const checkMessagesUrl = "https://serviceapi.markeplay.com/api/1.1/notifications/checkmessages";
    
    // LOGGING DI SICUREZZA PER CONFERMARE CHE VIENE USATO SEMPRE L'URL DIRETTO
    console.log('[ServiceWorker] 🔒 SICUREZZA MASSIMA: URL FISSO SEMPRE USATO:', checkMessagesUrl);
    console.log('[ServiceWorker] 🔒 L\'HOSTNAME NON IMPORTA:', self.location.hostname);
    console.log('[ServiceWorker] 🔒 NESSUNA CONDIZIONE PUÒ MODIFICARE QUESTO URL')
    
    // Log finale decisivo
    console.log('[ServiceWorker] URL FINALE UTILIZZATO PER CHECK MESSAGES:', {
      url: checkMessagesUrl,
      isDevelopment,
      isProduction,
      hostname: self.location.hostname,
      isForcedDirectUrl: !isDevelopment
    });
    
    // Source parameter - identifica l'origine della richiesta (service worker)
    const sourceParam = isProduction ? "app" : "replit";
    console.log('[ServiceWorker] Using source parameter:', sourceParam);
    
    // Otteniamo un uniqueId valido da qualche parte nei dati dell'utente
    let validUniqueId = null;
    
    // Verifica se l'utente ha un uniqueId (maiuscolo o minuscolo)
    if (user.uniqueId) {
      validUniqueId = user.uniqueId;
      console.log('[ServiceWorker] Using uniqueId from user data:', validUniqueId);
    } 
    else if (user.uniqueid) {
      validUniqueId = user.uniqueid;
      console.log('[ServiceWorker] Using lowercase uniqueid from user data:', validUniqueId);
    }
    // Se siamo qui e non abbiamo ancora un uniqueId, proviamo a cercarlo in altre proprietà
    else if (user.data && user.data.uniqueId) {
      validUniqueId = user.data.uniqueId;
      console.log('[ServiceWorker] Found uniqueId in user.data:', validUniqueId);
    }
    else if (user.data && user.data.uniqueid) {
      validUniqueId = user.data.uniqueid;
      console.log('[ServiceWorker] Found lowercase uniqueid in user.data:', validUniqueId);
    }
    
    // Verifica anche nelle proprietà dell'utente
    if (!validUniqueId) {
      // Stampa tutte le chiavi dell'oggetto utente per debug
      console.log('[ServiceWorker] User object keys:', Object.keys(user));
      
      // Ricerca ricorsiva di proprietà che potrebbero contenere uniqueId
      const searchForUniqueId = (obj, prefix = '') => {
        for (const key in obj) {
          if (typeof obj[key] === 'object' && obj[key] !== null) {
            searchForUniqueId(obj[key], `${prefix}${key}.`);
          } else if ((key.toLowerCase() === 'uniqueid' || key.toLowerCase().includes('unique')) && obj[key]) {
            console.log(`[ServiceWorker] Found potential uniqueId in ${prefix}${key}:`, obj[key]);
            if (!validUniqueId) validUniqueId = obj[key];
          }
        }
      };
      
      searchForUniqueId(user);
    }
    
    // Se non troviamo un uniqueId valido nei dati dell'utente, questo è un errore critico
    // Non possiamo inventare un ID fittizio perché il server lo rifiuterebbe
    if (!validUniqueId || validUniqueId.trim() === '') {
      console.error('[ServiceWorker] No valid uniqueId found in user data - CRITICAL ERROR');
      console.log('[ServiceWorker] USER OBJECT:', user);
      console.log('[ServiceWorker] Found uniqueId (empty/invalid):', validUniqueId);
      
      // Ultimo tentativo disperato: se l'utente ha un id, proviamo ad usare quello come uniqueId
      if (user && user.id && typeof user.id === 'string' && user.id.length > 3) {
        console.log('[ServiceWorker] Using user.id as last resort for uniqueId:', user.id);
        validUniqueId = user.id;
      } else {
        // Notifichiamo i client che è necessario fare login di nuovo
        const clients = await self.clients.matchAll({ type: 'window' });
        clients.forEach(client => {
          client.postMessage({ 
            type: 'UNIQUEID_MISSING',
            message: 'È necessario effettuare nuovamente il login'
          });
        });
        
        // Terminiamo l'esecuzione di questo controllo di notifiche
        // Non ha senso continuare senza un ID utente valido
        return;
      }
    }
    
    // Prepara il corpo della richiesta in base all'ambiente
    let requestBody;
    
    // Imposta l'uniqueId nell'oggetto utente per riferimenti futuri
    user.uniqueId = validUniqueId;
    user.uniqueid = validUniqueId;
    
    console.log('[ServiceWorker] Final uniqueId being used:', validUniqueId);
    
    // Utilizziamo validUniqueId per tutte le richieste
    const effectiveUniqueId = validUniqueId;
    
    if (isProduction) {
      // Corpo della richiesta formattato per l'API diretta di Markeplay
      requestBody = { 
        uniqueid: effectiveUniqueId, // Per compatibilità con l'API Markeplay (tutto minuscolo)
        culture: user.culture || navigator.language || 'it-IT',
        challenge_key: NOTIFICATION_CHALLENGE_KEY, // Formato principale
        source: sourceParam // Identifica l'origine come "app" in produzione
      };
    } else {
      // Corpo della richiesta completo per l'ambiente di sviluppo
      requestBody = { 
        userId: user.id,
        uniqueId: effectiveUniqueId, // Per compatibilità con il nostro backend
        uniqueid: effectiveUniqueId, // Per compatibilità con l'API Markeplay (tutto minuscolo)
        challenge_key: NOTIFICATION_CHALLENGE_KEY, // Formato principale
        notificationChallengeKey: NOTIFICATION_CHALLENGE_KEY, // Formato alternativo
        source: sourceParam // Identifica l'origine come "replit" in sviluppo
      };
    }
    
    console.log('[ServiceWorker] Request body for checkmessages:', JSON.stringify(requestBody, null, 2));
    
    // CORREZIONE CRITICA 9.0: L'URL è precedentemente stato generato per utilizzare sempre l'API diretta in produzione
    console.log('[ServiceWorker] VERIFICA FINALE URL UTILIZZATO:', {
      url: checkMessagesUrl,
      isDevelopment: isDevelopment,
      isProduction: isProduction,
      hostname: self.location.hostname
    });
    
    const markeplayResponse = await fetch(checkMessagesUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody),
    });
    
    // CORREZIONE 9.0: Verifica risposta API Markeplay
    console.log('[ServiceWorker] Risposta API Markeplay status:', markeplayResponse.status);
    
    // In produzione dobbiamo evitare di usare percorsi relativi che potrebbero combinarsi con il dominio dell'API
    // CORREZIONE 13.2: Forziamo anche qui l'URL diretto di Markeplay
    // Non dobbiamo usare /api/notifications che non esiste sul server Markeplay
    // Utilizziamo lo stesso URL del checkMessagesUrl per consistenza
    
    // URL HARDCODED ASSOLUTO senza condizioni
    const notificationsUrl = "https://serviceapi.markeplay.com/api/1.1/notifications/checkmessages";
    console.log('[ServiceWorker] CORREZIONE 13.2: Uso URL hardcoded per notifiche:', notificationsUrl);
    
    // Disabilita completamente questa chiamata che potrebbe duplicare le notifiche
    console.log('[ServiceWorker] IMPORTANTE: Questa chiamata è disabilitata per evitare duplicazioni');
    console.log('[ServiceWorker] Le notifiche vengono già gestite dalla chiamata checkMessagesUrl precedente');
    console.log('[ServiceWorker] Mantengo comunque questo blocco di codice per compatibilità futura');

    // Salto completamente questo fetch per evitare duplicazione delle notifiche
    const skipNotificationsFetch = true;
    
    // Creiamo una risposta fittizia per non disturbare il flusso del codice
    let response;
    
    if (skipNotificationsFetch) {
      // Creiamo un oggetto Response vuoto con notifiche vuote
      response = new Response(JSON.stringify({ notifications: [] }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
      console.log('[ServiceWorker] Risposta vuota creata per evitare duplicazioni notifiche');
    } else {
      // L'originale fetch è conservato ma non eseguito per evitare duplicazioni
      response = await fetch(notificationsUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId: user.id,
          uniqueId: effectiveUniqueId,
          uniqueid: effectiveUniqueId, // Usiamo lo stesso effectiveUniqueId calcolato prima
          challenge_key: NOTIFICATION_CHALLENGE_KEY,
          source: isProduction ? "app" : "replit" // Includiamo il parametro source anche qui
        })
      });
    }
    if (!response.ok) return;
    
    const data = await response.json();
    if (!data.success) return; // Ora usiamo solo il parametro success standardizzato
    
    const notifications = data.content;
    const unreadNotifications = notifications.filter(n => !n.read);
    
    if (unreadNotifications.length > 0) {
      // Mostriamo le ultime 3 notifiche non lette per evitare di sovraccaricare l'utente
      const recentNotifications = unreadNotifications.slice(0, 3);
      
      // Se ci sono notifiche non lette, notifichiamo i client per riprodurre un suono
      if (unreadNotifications.length > 0) {
        const clients = await self.clients.matchAll({ type: 'window' });
        clients.forEach(client => {
          client.postMessage({ 
            type: 'NEW_NOTIFICATIONS',
            count: unreadNotifications.length
          });
        });
      }
      
      // Verifica se abbiamo il permesso di mostrare notifiche
      // Questo è un controllo di sicurezza aggiuntivo anche se in teoria il service worker
      // dovrebbe essere registrato solo dopo che i permessi sono stati concessi
      try {
        const permissionStatus = self.Notification?.permission;
        
        // Se non abbiamo i permessi, logghiamo e usciamo senza errore
        if (permissionStatus !== 'granted') {
          console.log('Notification permission not granted yet. Permission status:', permissionStatus);
          
          // Inform client windows to request permission
          const clients = await self.clients.matchAll({ type: 'window' });
          clients.forEach(client => {
            client.postMessage({ 
              type: 'REQUEST_NOTIFICATION_PERMISSION'
            });
          });
          
          return; // Esci dalla funzione senza mostrare notifiche
        }
        
        // Abbiamo il permesso, procediamo a mostrare le notifiche
        for (const notification of recentNotifications) {
          await self.registration.showNotification('Markeplay Notifier', {
            body: notification.message,
            title: notification.title,
            icon: `${BASE_PATH}/icon-192x192.png`,
            badge: `${BASE_PATH}/icon-192x192.png`,
            image: notification.imageUrl || undefined,
            vibrate: [200, 100, 200],
            silent: false, // Assicuriamoci che la notifica non sia silenziosa
            data: {
              url: notification.link || `${BASE_PATH}/`,
              notificationId: notification.id,
              shouldPlaySound: true // Segnialiamo che dovrebbe essere riprodotto un suono
            }
          });
        }
      } catch (notificationError) {
        console.error('Error showing notifications:', notificationError);
      }
    }
  } catch (error) {
    console.error('Background notification check failed:', error);
  }
}

// Helper function to get user data from IndexedDB with reliable uniqueId extraction
async function getUser() {
  if (!indexedDB) {
    console.error('[ServiceWorker] IndexedDB not available');
    return null;
  }
  
  console.log('[ServiceWorker] Attempting to get user from IndexedDB');
  
  // Otteniamo l'uniqueId dal localStorage come fallback
  const getFromLocalStorage = () => {
    try {
      const storedUser = self.localStorage?.getItem("user");
      if (storedUser) {
        const user = JSON.parse(storedUser);
        console.log('[ServiceWorker] User found in localStorage:', user);
        if (user.uniqueId || user.uniqueid) {
          console.log('[ServiceWorker] Using uniqueId from localStorage:', user.uniqueId || user.uniqueid);
          return user;
        }
      }
    } catch (e) {
      console.error('[ServiceWorker] Error reading from localStorage:', e);
    }
    return null;
  };
  
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('markeplay-notifier', 1);
    
    request.onerror = (event) => {
      console.error('[ServiceWorker] Error opening IndexedDB:', event.target.error);
      // Tentiamo il fallback da localStorage
      const localUser = getFromLocalStorage();
      resolve(localUser);
    };
    
    request.onsuccess = (event) => {
      console.log('[ServiceWorker] IndexedDB opened successfully');
      const db = event.target.result;
      
      // Verifica che lo store esista
      if (!db.objectStoreNames.contains('user')) {
        console.error('[ServiceWorker] User store does not exist in IndexedDB');
        // Tentiamo il fallback da localStorage
        const localUser = getFromLocalStorage();
        resolve(localUser);
        return;
      }
      
      try {
        const transaction = db.transaction('user', 'readonly');
        const store = transaction.objectStore('user');
        
        // DEBUG: Enumeriamo tutti gli utenti presenti
        const getAllKeysRequest = store.getAllKeys();
        getAllKeysRequest.onsuccess = () => {
          const keys = getAllKeysRequest.result;
          console.log(`[ServiceWorker] Available user IDs in IndexedDB:`, keys);
          
          // Se non ci sono utenti, tentiamo il fallback
          if (!keys || keys.length === 0) {
            console.log('[ServiceWorker] No users found in IndexedDB, trying localStorage');
            const localUser = getFromLocalStorage();
            resolve(localUser);
            return;
          }
          
          // Ci sono utenti, procediamo con la ricerca
          // Invece di usare sempre l'ID 1, proviamo a usare il primo ID disponibile
          const firstId = keys[0];
          console.log(`[ServiceWorker] Using first available ID: ${firstId}`);
          
          const getRequest = store.get(firstId);
          
          getRequest.onsuccess = () => {
            const userData = getRequest.result;
            if (userData && (userData.uniqueId || userData.uniqueid)) {
              console.log('[ServiceWorker] User with uniqueId found using first ID:', userData);
              resolve(userData);
            } else {
              console.warn('[ServiceWorker] User found without uniqueId or with invalid ID, trying alternative approach');
              
              // Se non troviamo l'utente con ID valido o senza uniqueId, proviamo a recuperare TUTTI gli utenti
              const getAllRequest = store.getAll();
              getAllRequest.onsuccess = () => {
                const allUsers = getAllRequest.result;
                console.log('[ServiceWorker] All users from IndexedDB:', allUsers);
                
                if (allUsers && allUsers.length > 0) {
                  // Troviamo il primo utente con uniqueId o uniqueid
                  let validUser = allUsers.find(u => u.uniqueId || u.uniqueid);
                  
                  // Se non abbiamo trovato un utente con uniqueId esplicito,
                  // utilizziamo il primo utente disponibile
                  if (!validUser) {
                    validUser = allUsers[0];
                  }
                  
                  console.log('[ServiceWorker] Selected user from all available:', validUser);
                  
                  // La funzione checkForNewNotifications cercherà di estrarre l'uniqueId
                  // da qualsiasi parte dell'oggetto
                  
                  // Preserviamo l'ID originale dell'utente ma con fallback sicuro
                  const user = {
                    ...validUser,
                    // Usiamo l'ID esistente ma con un fallback a timestamp se non esiste
                    id: validUser.id || Date.now()
                  };
                  
                  // Verifichiamo immediatamente che uniqueId sia presente o lo estraiamo da uniqueid
                  if (validUser.uniqueId) {
                    user.uniqueId = validUser.uniqueId;
                    console.log('[ServiceWorker] Using existing uniqueId property:', user.uniqueId);
                  } else if (validUser.uniqueid) {
                    user.uniqueId = validUser.uniqueid;
                    user.uniqueid = validUser.uniqueid;
                    console.log('[ServiceWorker] Copied uniqueid to uniqueId property:', user.uniqueId);
                  }
                  
                  // Logging dettagliato delle chiavi
                  console.log('[ServiceWorker] User object keys available:', Object.keys(user));
                  
                  // Se per caso l'oggetto user ha una proprietà 'user', estraiamo i dati da lì
                  if (user.user && typeof user.user === 'object') {
                    console.log('[ServiceWorker] Found nested user object, merging properties');
                    Object.assign(user, user.user);
                  }
                  
                  // Se per caso abbiamo una proprietà .data nell'utente, estraila
                  if (user.data && typeof user.data === 'object') {
                    console.log('[ServiceWorker] Found data property, checking for uniqueId');
                    if (user.data.uniqueId || user.data.uniqueid) {
                      user.uniqueId = user.data.uniqueId || user.data.uniqueid;
                      console.log('[ServiceWorker] Extracted uniqueId from data property:', user.uniqueId);
                    }
                  }
                  
                  // Prova a trovare il campo uniqueId in modo generico in qualsiasi proprietà di primo livello
                  if (!user.uniqueId && !user.uniqueid) {
                    for (const key in user) {
                      if (typeof user[key] === 'string' && user[key].length > 3) {
                        if (key.toLowerCase().includes('unique') || key.toLowerCase().includes('userid')) {
                          console.log(`[ServiceWorker] Found potential uniqueId in ${key}:`, user[key]);
                          user.uniqueId = user[key];
                          break;
                        }
                      }
                    }
                  }
                  
                  console.log('[ServiceWorker] Using user object:', user);
                  resolve(user);
                } else {
                  console.error('[ServiceWorker] No users found in IndexedDB');
                  // Tentiamo il fallback da localStorage
                  const localUser = getFromLocalStorage();
                  resolve(localUser);
                }
              };
              
              getAllRequest.onerror = (error) => {
                console.error('[ServiceWorker] Error getting all users:', error);
                // Tentiamo il fallback da localStorage
                const localUser = getFromLocalStorage();
                resolve(localUser);
              };
            }
          };
          
          getRequest.onerror = (error) => {
            console.error(`[ServiceWorker] Error getting user with ID ${firstId}:`, error);
            // Tentiamo il fallback da localStorage
            const localUser = getFromLocalStorage();
            resolve(localUser);
          };
        };
        
        getAllKeysRequest.onerror = (error) => {
          console.error('[ServiceWorker] Error getting keys:', error);
          // Tentiamo il fallback da localStorage
          const localUser = getFromLocalStorage();
          resolve(localUser);
        };
      } catch (e) {
        console.error('[ServiceWorker] Transaction error:', e);
        // Tentiamo il fallback da localStorage
        const localUser = getFromLocalStorage();
        resolve(localUser);
      }
    };
    
    request.onupgradeneeded = (event) => {
      console.log('[ServiceWorker] Upgrading IndexedDB database schema');
      const db = event.target.result;
      if (!db.objectStoreNames.contains('user')) {
        db.createObjectStore('user', { keyPath: 'id' });
        console.log('[ServiceWorker] Created user object store');
      }
    };
  });
}